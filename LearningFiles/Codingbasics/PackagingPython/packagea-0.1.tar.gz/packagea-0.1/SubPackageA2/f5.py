def print_something():
    return "output from f5"